// Schema.org markup for Google
const schemaMarkup = () => {
  // Article Schema
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Subnetting Made Simple: Complete Beginner's Guide",
    "description": "Learn IP subnetting easily with our beginner-friendly guide. Includes practical examples and subnet calculator tool.",
    "author": {
      "@type": "Organization",
      "name": "TheIPChecker",
      "url": "https://theipchecker.com"
    },
    "datePublished": "2023-10-15",
    "dateModified": "2023-10-15",
    "publisher": {
      "@type": "Organization",
      "name": "TheIPChecker",
      "logo": {
        "@type": "ImageObject",
        "url": "https://theipchecker.com/images/logo.png",
        "width": 300,
        "height": 60
      }
    },
    "image": {
      "@type": "ImageObject",
      "url": "https://theipchecker.com/images/subnet-edu.png",
      "width": 1200,
      "height": 630
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://theipchecker.com/subnetting-guide"
    },
    "speakable": {
      "@type": "SpeakableSpecification",
      "xPath": [
        "/html/head/title",
        "/html/body/main/h1",
        "/html/body/main/p[1]"
      ]
    },
    "keywords": ["subnetting", "IP subnetting", "subnet calculator", "network subnetting", "CIDR notation", "subnet mask"],
    "articleBody": "Subnetting is the process of dividing a single network into smaller, more efficient subnetworks. This essential networking skill helps optimize IP address allocation, improve security, and reduce network congestion."
  };

  // FAQ Schema
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is subnetting in networking?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Subnetting is the process of dividing a larger network into smaller logical subnetworks to improve network efficiency, security, and IP address management."
        }
      },
      {
        "@type": "Question",
        "name": "How does subnetting improve network performance?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Subnetting reduces network congestion by limiting broadcast traffic to smaller subnetworks and enables more efficient routing of network traffic."
        }
      },
      {
        "@type": "Question",
        "name": "What's the difference between CIDR and subnet mask?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "CIDR (Classless Inter-Domain Routing) notation represents subnet masks in a shortened format (like /24), while traditional subnet masks use the dotted decimal format (like 255.255.255.0). Both serve the same purpose but in different formats."
        }
      }
    ]
  };

  // Breadcrumb Schema
  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://theipchecker.com"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Education",
        "item": "https://theipchecker.com/education"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": "Subnetting Guide",
        "item": "https://theipchecker.com/subneting-guide"
      }
    ]
  };

  // Function to inject schema
  const injectSchema = (schema) => {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schema);
    document.head.appendChild(script);
  };

  // Inject all schemas
  injectSchema(articleSchema);
  injectSchema(faqSchema);
  injectSchema(breadcrumbSchema);
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', schemaMarkup);