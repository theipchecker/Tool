
        // Load header
        fetch('header-main.html')
            .then(response => response.text())
            .then(html => {
                document.getElementById('header-placeholder').innerHTML = html;
                initializeMobileMenu();
            })
            .catch(error => console.error('Header load error:', error));

        // Load footer
        fetch('footer.html')
            .then(response => response.text())
            .then(html => {
                document.getElementById('footer-placeholder').innerHTML = html;
                document.getElementById('current-year').textContent = new Date().getFullYear();
            })
            .catch(error => console.error('Footer load error:', error));

        // Mobile Menu Initialization
        function initializeMobileMenu() {
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mainNav = document.getElementById('main-nav');
            const dropdowns = document.querySelectorAll('.dropdown');
            
            if (mobileMenuBtn && mainNav) {
                mobileMenuBtn.addEventListener('click', function() {
                    mainNav.classList.toggle('active');
                    this.textContent = mainNav.classList.contains('active') ? '✕' : '☰';
                });
            }
            
            dropdowns.forEach(dropdown => {
                const link = dropdown.querySelector('a');
                link.addEventListener('click', function(e) {
                    if (window.innerWidth > 992) return;
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                });
            });
        }

        // Base64 Tool Functionality
        document.addEventListener('DOMContentLoaded', function() {
            const encodeTab = document.getElementById('encode-tab');
            const decodeTab = document.getElementById('decode-tab');
            const inputLabel = document.getElementById('input-label');
            const inputText = document.getElementById('input-text');
            const outputText = document.getElementById('output-text');
            const processBtn = document.getElementById('process-btn');
            const clearBtn = document.getElementById('clear-btn');
            const copyInputBtn = document.getElementById('copy-input');
            const copyOutputBtn = document.getElementById('copy-output');
            const downloadBtn = document.getElementById('download-btn');
            const errorMessage = document.getElementById('error-message');
            
            let currentMode = 'encode';
            
            // Tab switching
            encodeTab.addEventListener('click', function() {
                currentMode = 'encode';
                encodeTab.classList.add('active');
                decodeTab.classList.remove('active');
                inputLabel.textContent = 'Text to encode:';
                inputText.placeholder = 'Enter text to encode to Base64';
                processBtn.textContent = 'Encode';
                outputText.value = '';
                errorMessage.textContent = '';
            });
            
            decodeTab.addEventListener('click', function() {
                currentMode = 'decode';
                encodeTab.classList.remove('active');
                decodeTab.classList.add('active');
                inputLabel.textContent = 'Base64 to decode:';
                inputText.placeholder = 'Enter Base64 to decode to text';
                processBtn.textContent = 'Decode';
                outputText.value = '';
                errorMessage.textContent = '';
            });
            
            // Process button
            processBtn.addEventListener('click', function() {
                try {
                    errorMessage.textContent = '';
                    
                    if (currentMode === 'encode') {
                        // Encode to Base64
                        const encoded = btoa(unescape(encodeURIComponent(inputText.value)));
                        outputText.value = encoded;
                    } else {
                        // Decode from Base64
                        const decoded = decodeURIComponent(escape(atob(inputText.value)));
                        outputText.value = decoded;
                    }
                } catch (e) {
                    errorMessage.textContent = 'Error: ' + e.message;
                    if (currentMode === 'decode') {
                        errorMessage.textContent += ' (Invalid Base64 input)';
                    }
                }
            });
            
            // Clear button
            clearBtn.addEventListener('click', function() {
                inputText.value = '';
                outputText.value = '';
                errorMessage.textContent = '';
            });
            
            // Copy buttons
            copyInputBtn.addEventListener('click', function() {
                inputText.select();
                document.execCommand('copy');
            });
            
            copyOutputBtn.addEventListener('click', function() {
                outputText.select();
                document.execCommand('copy');
            });
            
            // Download button
            downloadBtn.addEventListener('click', function() {
                if (!outputText.value) return;
                
                const blob = new Blob([outputText.value], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = currentMode === 'encode' ? 'encoded.txt' : 'decoded.txt';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            });
            
            // Auto-focus input field
            inputText.focus();
        });
