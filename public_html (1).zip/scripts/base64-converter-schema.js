// Schema.org structured data
function injectSchemas() {
  // Main Tool Schema
  const toolSchema = {
    "@context": "https://schema.org",
    "@type": ["WebApplication", "Tool"],
    "name": "Base64 Encoder/Decoder Online",
    "url": "https://theipchecker.com/base64-converter",
    "description": "Free online Base64 encoder and decoder tool. Instantly convert text to Base64 and decode Base64 back to text. No data leaves your browser.",
    "applicationCategory": "DataConverter",
    "operatingSystem": "Any",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "creator": {
      "@type": "Organization",
      "name": "TheIPChecker",
      "url": "https://theipchecker.com"
    },
    "publisher": {
      "@type": "Organization",
      "name": "TheIPChecker",
      "logo": {
        "@type": "ImageObject",
        "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.png",
        "width": 192,
        "height": 192
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://theipchecker.com/base64-converter"
    },
    "image": {
      "@type": "ImageObject",
      "url": "https://theipchecker.com/images/base64-converter-tool.png",
      "width": 1200,
      "height": 630
    },
    "interactionStatistic": {
      "@type": "InteractionCounter",
      "interactionType": "https://schema.org/UseAction",
      "userInteractionCount": 5000
    },
    "potentialAction": [
      {
        "@type": "Action",
        "name": "Encode to Base64",
        "description": "Convert text to Base64 encoding",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://theipchecker.com/base64-converter",
          "actionPlatform": [
            "http://schema.org/DesktopWebPlatform",
            "http://schema.org/MobileWebPlatform"
          ]
        }
      },
      {
        "@type": "Action",
        "name": "Decode from Base64",
        "description": "Convert Base64 back to original text",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://theipchecker.com/base64-converter",
          "actionPlatform": [
            "http://schema.org/DesktopWebPlatform",
            "http://schema.org/MobileWebPlatform"
          ]
        }
      }
    ],
    "featureList": [
      "Text to Base64 encoding",
      "Base64 to text decoding",
      "Client-side processing (no server transfer)",
      "Copy to clipboard",
      "Download results",
      "Secure local processing"
    ],
    "screenshot": {
      "@type": "ImageObject",
      "url": "https://theipchecker.com/images/base64-converter-screenshot.png",
      "width": 1280,
      "height": 720
    }
  };

  // FAQ Schema
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Why use Base64 encoding?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Base64 is used when you need to encode binary data to be safely transported over systems that only support text content, like email attachments (MIME), embedding images in HTML/CSS (data URIs), storing complex data in JSON/XML, or for basic obfuscation of sensitive data."
        }
      },
      {
        "@type": "Question",
        "name": "Is Base64 secure for passwords?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "No, Base64 is not encryption - it's just encoding. Anyone can decode Base64 data easily. For passwords, always use proper hashing algorithms like bcrypt or Argon2."
        }
      },
      {
        "@type": "Question",
        "name": "What characters are in Base64?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Base64 uses these 64 characters: A-Z, a-z, 0-9, plus + and /. The = character is used for padding at the end."
        }
      },
      {
        "@type": "Question",
        "name": "Does this tool send my data to a server?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "No, all encoding and decoding happens completely in your browser. Your data never leaves your device, ensuring maximum privacy."
        }
      }
    ]
  };

  // Create script tags and inject into head
  const script1 = document.createElement('script');
  script1.type = 'application/ld+json';
  script1.text = JSON.stringify(toolSchema);
  document.head.appendChild(script1);

  const script2 = document.createElement('script');
  script2.type = 'application/ld+json';
  script2.text = JSON.stringify(faqSchema);
  document.head.appendChild(script2);
}

// Run when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectSchemas);
} else {
  injectSchemas();
}