        
        // // Instead of style.display = "block"
        // document.getElementById("result-section").classList.add("visible");

        // // Instead of style.display = "none"
        // document.getElementById("result-section").classList.remove("visible");

        
        // Load header
        fetch('header-main.html')
            .then(response => response.text())
            .then(html => {
                document.getElementById('header-placeholder').innerHTML = html;
                initializeMobileMenu();
            })
            .catch(error => console.error('Header load error:', error));

        // Load footer
        fetch('footer.html')
            .then(response => response.text())
            .then(html => {
                document.getElementById('footer-placeholder').innerHTML = html;
                // Update copyright year
                document.getElementById('current-year').textContent = new Date().getFullYear();
            })
            .catch(error => console.error('Footer load error:', error));

        // Mobile Menu Initialization
        function initializeMobileMenu() {
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mainNav = document.getElementById('main-nav');
            const dropdowns = document.querySelectorAll('.dropdown');
            
            if (mobileMenuBtn && mainNav) {
                mobileMenuBtn.addEventListener('click', function() {
                    mainNav.classList.toggle('active');
                    this.textContent = mainNav.classList.contains('active') ? '✕' : '☰';
                });
            }
            
            // Handle dropdowns on mobile
            dropdowns.forEach(dropdown => {
                const link = dropdown.querySelector('a');
                link.addEventListener('click', function(e) {
                    if (window.innerWidth > 992) return;
                    
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                });
            });
        }
        document.addEventListener('DOMContentLoaded', function() {
            const cidrInput = document.getElementById('cidr-input');
            const convertBtn = document.getElementById('convert-btn');
            const errorMessage = document.getElementById('error-message');
            const resultSection = document.getElementById('result-section');
            
            // Result fields
            const cidrOutput = document.getElementById('cidr-output');
            const networkAddress = document.getElementById('network-address');
            const hostRange = document.getElementById('host-range');
            const broadcastAddress = document.getElementById('broadcast-address');
            const totalHosts = document.getElementById('total-hosts');
            const subnetMask = document.getElementById('subnet-mask');
            const wildcardMask = document.getElementById('wildcard-mask');
            const ipList = document.getElementById('ip-list');
            

            
            convertBtn.addEventListener('click', convertCIDR);
            cidrInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    convertCIDR();
                }
            });
            
            function convertCIDR() {
                errorMessage.textContent = '';
                resultSection.style.display = 'none';
                
                const cidr = cidrInput.value.trim();
                if (!cidr) {
                    errorMessage.textContent = 'Please enter a CIDR notation';
                    return;
                }
                
                try {
                    const result = calculateCIDRRange(cidr);
                    displayResults(result);
                } catch (e) {
                    errorMessage.textContent = e.message;
                }
            }
            
            function calculateCIDRRange(cidr) {
                // Validate CIDR format
                const cidrRegex = /^([0-9]{1,3}\.){3}[0-9]{1,3}\/([0-9]|[1-2][0-9]|3[0-2])$/;
                if (!cidrRegex.test(cidr)) {
                    throw new Error('Invalid CIDR format. Please use format like 192.168.0.0/24');
                }
                
                const [ip, prefix] = cidr.split('/');
                const prefixLength = parseInt(prefix, 10);
                
                if (prefixLength < 0 || prefixLength > 32) {
                    throw new Error('Prefix length must be between 0 and 32');
                }
                
                // Validate IP address
                const ipParts = ip.split('.').map(part => parseInt(part, 10));
                if (ipParts.length !== 4 || ipParts.some(isNaN)) {
                    throw new Error('Invalid IP address');
                }
                if (ipParts.some(part => part < 0 || part > 255)) {
                    throw new Error('IP address parts must be between 0 and 255');
                }
                
                // Calculate subnet mask
                const subnetMask = calculateSubnetMask(prefixLength);
                
                // Calculate network address (first IP)
                const networkAddress = ipParts.map((part, i) => part & subnetMask[i]);
                
                // Calculate broadcast address (last IP)
                const wildcardMask = subnetMask.map(part => 255 - part);
                const broadcastAddress = networkAddress.map((part, i) => part | wildcardMask[i]);
                
                // Calculate total hosts
                const totalHosts = Math.pow(2, 32 - prefixLength);
                const usableHosts = totalHosts > 2 ? totalHosts - 2 : totalHosts;
                
                // Generate IP range
                const ipRange = generateIPRange(networkAddress, broadcastAddress, prefixLength);
                
                return {
                    cidrNotation: cidr,
                    networkAddress: networkAddress.join('.'),
                    firstUsableHost: totalHosts > 1 ? incrementIP([...networkAddress]).join('.') : networkAddress.join('.'),
                    lastUsableHost: totalHosts > 1 ? decrementIP([...broadcastAddress]).join('.') : broadcastAddress.join('.'),
                    broadcastAddress: broadcastAddress.join('.'),
                    totalHosts: totalHosts,
                    usableHosts: usableHosts,
                    subnetMask: subnetMask.join('.'),
                    wildcardMask: wildcardMask.join('.'),
                    ipRange: ipRange
                };
            }
            
            function calculateSubnetMask(prefixLength) {
                const mask = [];
                for (let i = 0; i < 4; i++) {
                    const bits = Math.min(8, Math.max(0, prefixLength - i * 8));
                    mask.push(bits === 0 ? 0 : 256 - Math.pow(2, 8 - bits));
                }
                return mask;
            }
            
            function generateIPRange(start, end, prefixLength) {
                const ips = [];
                const current = [...start];
                const maxDisplay = 100; // Limit for display
                
                // For small ranges (<= maxDisplay), show all IPs
                if (Math.pow(2, 32 - prefixLength) <= maxDisplay) {
                    while (compareIPs(current, end) <= 0) {
                        ips.push(current.join('.'));
                        incrementIP(current);
                    }
                    return ips.join('\n');
                }
                
                // For large ranges, show first and last 10 IPs
                let count = 0;
                while (count < 10 && compareIPs(current, end) <= 0) {
                    ips.push(current.join('.'));
                    incrementIP(current);
                    count++;
                }
                
                ips.push('...');
                
                // Get last 10 IPs
                const lastIPs = [];
                const temp = [...end];
                count = 0;
                while (count < 10) {
                    lastIPs.unshift(temp.join('.'));
                    decrementIP(temp);
                    count++;
                }
                
                return ips.concat(lastIPs).join('\n');
            }
            
            function incrementIP(ip) {
                for (let i = 3; i >= 0; i--) {
                    if (ip[i] < 255) {
                        ip[i]++;
                        return ip;
                    }
                    ip[i] = 0;
                }
                return ip;
            }
            
            function decrementIP(ip) {
                for (let i = 3; i >= 0; i--) {
                    if (ip[i] > 0) {
                        ip[i]--;
                        return ip;
                    }
                    ip[i] = 255;
                }
                return ip;
            }
            
            function compareIPs(ip1, ip2) {
                for (let i = 0; i < 4; i++) {
                    if (ip1[i] < ip2[i]) return -1;
                    if (ip1[i] > ip2[i]) return 1;
                }
                return 0;
            }
            
            function displayResults(result) {
                cidrOutput.textContent = result.cidrNotation;
                networkAddress.textContent = result.networkAddress;
                hostRange.textContent = `${result.firstUsableHost} - ${result.lastUsableHost}`;
                broadcastAddress.textContent = result.broadcastAddress;
                totalHosts.textContent = `${result.usableHosts} usable (${result.totalHosts} total)`;
                subnetMask.textContent = result.subnetMask;
                wildcardMask.textContent = result.wildcardMask;
                ipList.textContent = result.ipRange;
                
                if (result.totalHosts > 100) {
                    ipList.innerHTML += '<div style="color: var(--dark-gray); margin-top: 10px;">Note: Displaying first and last 10 IPs only for large ranges.</div>';
                }
                
                resultSection.style.display = 'block';
            }
        });
   