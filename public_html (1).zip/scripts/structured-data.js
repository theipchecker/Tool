// scripts/structured-data.js
document.addEventListener('DOMContentLoaded', function() {
  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebApplication",
        "name": "TheIPChecker",
        "url": "https://www.theipchecker.com",
        "description": "Free online IP tools and network utilities including IP lookup, VPN leak testing, subnet calculation, and Base64 converter.",
        "applicationCategory": "NetworkApplication",
        "operatingSystem": "Any",
        "mainEntity": {
          "@type": "ItemList",
          "itemListElement": [
            {
              "@type": "ListItem",
              "position": 1,
              "name": "IP Address Lookup",
              "url": "https://www.theipchecker.com"
            },
            {
              "@type": "ListItem",
              "position": 2,
              "name": "VPN Leak Test",
              "url": "https://www.theipchecker.com/vpn-leak-test"
            },
            {
              "@type": "ListItem",
              "position": 3,
              "name": "Subnet Calculator",
              "url": "https://www.theipchecker.com/subnet-calculator"
            },
            {
              "@type": "ListItem",
              "position": 4,
              "name": "Base64 Converter",
              "url": "https://www.theipchecker.com/base64-converter"
            }
          ]
        },
        "offers": {
          "@type": "Offer",
          "price": "0",
          "priceCurrency": "USD"
        },
        "creator": {
          "@type": "Organization",
          "name": "TheIPChecker",
          "url": "https://www.theipchecker.com",
          "logo": {
            "@type": "ImageObject",
            "url": "https://www.theipchecker.com/logo.webp",
            "width": 300,
            "height": 300
          }
        },
        "screenshot": {
          "@type": "ImageObject",
          "url": "https://www.theipchecker.com/screenshot.webp",
          "width": 1280,
          "height": 720
        }
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What is an IP address?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "An IP (Internet Protocol) address is a unique identifier assigned to every device connected to a network."
            }
          },
          {
            "@type": "Question",
            "name": "How accurate is IP geolocation?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "IP geolocation typically provides city-level accuracy, though VPNs and proxies may affect results."
            }
          }
          // Add other FAQ items from your HTML
        ]
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://www.theipchecker.com"
          }
        ]
      }
    ]
  };

  // Create and inject script
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.text = JSON.stringify(structuredData);
  document.head.appendChild(script);
});