// JSON-LD Schema for Education Collection Page
document.addEventListener('DOMContentLoaded', function() {
    const schema = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Networking & Cybersecurity Educational Resources",
        "description": "Learn about networking, privacy, and security with comprehensive guides and tutorials from TheIPChecker.",
        "url": "https://theipchecker.com/education",
        "publisher": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "logo": {
                "@type": "ImageObject",
                "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.png",
                "width": 192,
                "height": 192
            }
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://theipchecker.com/education"
        },
        "image": {
            "@type": "ImageObject",
            "url": "https://theipchecker.com/images/education.jpg",
            "width": 1200,
            "height": 630
        },
        "hasPart": [
            {
                "@type": "Article",
                "name": "Understanding IP Addresses",
                "url": "https://theipchecker.com/what-is-ip-address",
                "description": "Learn how IP addresses work, the difference between IPv4 and IPv6, and how they enable internet communication.",
                "about": "Networking",
                "image": "https://theipchecker.com/images/cidr.png"
            },
            {
                "@type": "Article",
                "name": "The Complete VPN Guide",
                "url": "https://theipchecker.com/vpn-article",
                "description": "Everything you need to know about VPNs - how they work, why you need one, and how to choose the best service.",
                "about": "Security",
                "image": "https://theipchecker.com/images/vpn.png"
            },
            {
                "@type": "Article",
                "name": "Online Privacy Fundamentals",
                "url": "https://theipchecker.com/online-safety-privacy-article",
                "description": "Protect your digital footprint with these essential privacy practices for everyday internet use.",
                "about": "Privacy",
                "image": "https://theipchecker.com/images/privacy.jpeg"
            },
            {
                "@type": "Article",
                "name": "Subnetting Made Simple",
                "url": "https://theipchecker.com/subnetting-guide",
                "description": "A beginner-friendly guide to IP subnetting, complete with practical examples and our subnet calculator tool.",
                "about": "Networking",
                "image": "https://theipchecker.com/images/subnet-edu.png"
            },
            {
                "@type": "Article",
                "name": "Encryption Explained",
                "url": "https://theipchecker.com/encryption-edu",
                "description": "Understand how encryption protects your data online, from HTTPS to end-to-end encrypted messaging.",
                "about": "Security",
                "image": "https://theipchecker.com/images/base64-converter-tool.png"
            },
            {
                "@type": "Article",
                "name": "How DNS Works",
                "url": "https://theipchecker.com/dns-guide",
                "description": "Discover the Domain Name System - the phonebook of the internet that translates domains to IP addresses.",
                "about": "Networking",
                "image": "https://theipchecker.com/images/dns2.jpg"
            }
        ],
        "keywords": [
            "networking education",
            "privacy guides",
            "security tutorials",
            "IP address learning",
            "VPN education",
            "DNS explanation",
            "subnetting guide",
            "encryption tutorial"
        ]
    };

    // Create script tag and inject schema
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schema);
    document.head.appendChild(script);
});