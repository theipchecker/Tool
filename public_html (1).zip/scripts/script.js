
    document.addEventListener('DOMContentLoaded', function() {
    // Enhanced Header Loading
    fetch('header-main.html')
        .then(response => {
            if (!response.ok) throw new Error('Header load failed');
            return response.text();
        })
        .then(html => {
            document.getElementById('header-placeholder').innerHTML = html;
            initializeMobileMenu();
        })
        .catch(error => console.error('Header load error:', error));

    // Enhanced Footer Loading with CSS enforcement
    fetch('footer.html')
        .then(response => {
            if (!response.ok) throw new Error('Footer load failed');
            return response.text();
        })
        .then(html => {
            const placeholder = document.getElementById('footer-placeholder');
            placeholder.innerHTML = html;
            
            // Ensure footer CSS is loaded
            if (!document.querySelector('link[href="style/footer.css"]')) {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = 'style/footer.css';
                document.head.appendChild(link);
            }
            
            // Update copyright year
            const yearElement = placeholder.querySelector('#current-year');
            if (yearElement) {
                yearElement.textContent = new Date().getFullYear();
            }
        })
        .catch(error => console.error('Footer load error:', error));

    // IP Lookup Functionality (using the more robust old version)
    const showIpBtn = document.getElementById('showIpBtn');
    if (showIpBtn) {
        showIpBtn.addEventListener('click', detectIP);
    }
});

// Mobile Menu Initialization (from new version, improved)
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mainNav = document.getElementById('main-nav');
    const dropdowns = document.querySelectorAll('.dropdown');
    
    if (mobileMenuBtn && mainNav) {
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            this.textContent = mainNav.classList.contains('active') ? '✕' : '☰';
        });
    }
    
    // Handle dropdowns on mobile
    dropdowns.forEach(dropdown => {
        const link = dropdown.querySelector('a');
        link.addEventListener('click', function(e) {
            if (window.innerWidth > 992) return;
            
            e.preventDefault();
            dropdown.classList.toggle('active');
        });
    });
}

// IP Detection Functions (from old version - more robust)
const progressContainer = document.getElementById('progressContainer');
const progressBar = document.getElementById('progressBar');
const ipDisplay = document.getElementById('ipDisplay');
const ipDetails = document.getElementById('ipDetails');

async function detectIP() {
    try {
        // Hide previous results and show progress
        ipDisplay.style.display = 'none';
        ipDetails.style.display = 'none';
        progressContainer.style.display = 'block';
        showIpBtn.disabled = true;
        showIpBtn.textContent = 'Detecting...';
        
        // Show loading progress
        await animateProgressBar();
        
        // Get IP address
        const ip = await fetchIP();
        document.getElementById('ipAddress').textContent = ip;
        
        // Get location details
        const locationData = await fetchLocation(ip);
        
        // Update display
        updateDisplay(ip, locationData);
        
        // Show results
        ipDisplay.style.display = 'block';
        ipDetails.style.display = 'grid';
        progressContainer.style.display = 'none';
        showIpBtn.disabled = false;
        showIpBtn.textContent = 'Refresh IP';
        
    } catch (error) {
        console.error("Error detecting IP:", error);
        progressBar.textContent = "Error detecting IP";
        document.getElementById('ipAddress').textContent = "Unable to determine IP";
        showIpBtn.disabled = false;
        showIpBtn.textContent = 'Try Again';
    }
}

function animateProgressBar() {
    return new Promise(resolve => {
        let progress = 0;
        const duration = 3000;
        const interval = 30;
        const increment = (interval / duration) * 100;
        
        const timer = setInterval(() => {
            progress += increment;
            if (progress >= 100) {
                progress = 100;
                clearInterval(timer);
                resolve();
            }
            progressBar.style.width = `${progress}%`;
            progressBar.textContent = `Detecting your IP... ${Math.round(progress)}%`;
        }, interval);
    });
}

async function fetchIP() {
    const services = [
        'https://api.ipify.org?format=json',
        'https://ipapi.co/json/',
        'https://ipinfo.io/json',
        'https://api.myip.com'
    ];
    
    for (const url of services) {
        try {
            const response = await fetch(url, { 
                signal: AbortSignal.timeout(2000) 
            });
            const data = await response.json();
            return data.ip || data.query;
        } catch (e) {
            console.log(`Service ${url} failed, trying next`);
        }
    }
    throw new Error("All IP services failed");
}

async function fetchLocation(ip) {
    try {
        // Try ipapi.co first
        const response = await fetch(`https://ipapi.co/${ip}/json/`);
        if (response.ok) {
            const data = await response.json();
            return {
                country: data.country_name || 'Unknown',
                city: data.city || 'Unknown',
                org: data.org || 'Unknown',
                version: data.version || (ip.includes(':') ? 'IPv6' : 'IPv4')
            };
        }
    } catch (e) {
        console.log("ipapi.co failed, trying ipinfo.io");
    }
    
    try {
        // Fallback to ipinfo.io
        const response = await fetch(`https://ipinfo.io/${ip}/json`);
        if (response.ok) {
            const data = await response.json();
            return {
                country: data.country || 'Unknown',
                city: data.city || 'Unknown',
                org: data.org || 'Unknown',
                version: ip.includes(':') ? 'IPv6' : 'IPv4'
            };
        }
    } catch (e) {
        console.log("ipinfo.io failed");
    }
    
    // Return defaults if all services fail
    return {
        country: 'Unknown',
        city: 'Unknown',
        org: 'Unknown',
        version: ip.includes(':') ? 'IPv6' : 'IPv4'
    };
}

function updateDisplay(ip, data) {
    const ipAddress = document.getElementById('ipAddress');
    const ipVersion = document.getElementById('ipVersion');
    const country = document.getElementById('country');
    const city = document.getElementById('city');
    const isp = document.getElementById('isp');
    
    ipAddress.textContent = ip;
    ipVersion.textContent = data.version;
    ipVersion.className = data.version === 'IPv6' ? 'ipv6' : 'ipv4';
    country.textContent = data.country;
    city.textContent = data.city;
    isp.textContent = data.org;
    
    // Style IP version tag
    ipVersion.style.display = 'inline-block';
    ipVersion.style.padding = '2px 8px';
    ipVersion.style.borderRadius = '4px';
    ipVersion.style.fontSize = '0.9rem';
    ipVersion.style.marginLeft = '10px';
    ipVersion.style.color = 'white';
    ipVersion.style.backgroundColor = data.version === 'IPv6' ? '#e74c3c' : '#2ecc71';
}
 