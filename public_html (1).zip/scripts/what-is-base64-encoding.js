
        // Load header
        fetch('header-main.html')
            .then(response => response.text())
            .then(html => {
                document.getElementById('header-placeholder').innerHTML = html;
                initializeMobileMenu();
            })
            .catch(error => console.error('Header load error:', error));

        // Load footer
        fetch('footer.html')
            .then(response => response.text())
            .then(html => {
                document.getElementById('footer-placeholder').innerHTML = html;
                // Update copyright year
                document.getElementById('current-year').textContent = new Date().getFullYear();
            })
            .catch(error => console.error('Footer load error:', error));

        // Mobile Menu Initialization
        function initializeMobileMenu() {
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mainNav = document.getElementById('main-nav');
            const dropdowns = document.querySelectorAll('.dropdown');
            
            if (mobileMenuBtn && mainNav) {
                mobileMenuBtn.addEventListener('click', function() {
                    mainNav.classList.toggle('active');
                    this.textContent = mainNav.classList.contains('active') ? '✕' : '☰';
                });
            }
            
            // Handle dropdowns on mobile
            dropdowns.forEach(dropdown => {
                const link = dropdown.querySelector('a');
                link.addEventListener('click', function(e) {
                    if (window.innerWidth > 992) return;
                    
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                });
            });
        }
 
 