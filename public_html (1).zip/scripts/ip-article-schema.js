// ip-article-schema.js
const ipArticleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "What Is an IP Address? The Complete Guide | TheIPChecker",
  "name": "Understanding IP Addresses",
  "url": "https://theipchecker.com/what-is-ip-address",
  "description": "Learn how IP addresses work, the difference between IPv4 and IPv6, and how they enable internet communication.",
  "author": {
    "@type": "Organization",
    "name": "TheIPChecker",
    "url": "https://theipchecker.com",
    "sameAs": [
      "https://twitter.com/TheIPChecker",
      "https://facebook.com/TheIPChecker"
    ]
  },
  "datePublished": "2024-07-20",
  "dateModified": "2024-07-20",
  "publisher": {
    "@type": "Organization",
    "name": "TheIPChecker",
    "logo": {
      "@type": "ImageObject",
      "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.webp",
      "width": 192,
      "height": 192
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://theipchecker.com/what-is-ip-address"
  },
  "image": {
    "@type": "ImageObject",
    "url": "https://theipchecker.com/images/ip-address-cover.webp",
    "width": 1200,
    "height": 630,
    "caption": "Visual explanation of IP addresses and how they work"
  },
  "keywords": [
    "IP address",
    "what is my IP",
    "find IP address",
    "hide IP",
    "IP lookup",
    "IP tracker",
    "online privacy"
  ],
  "articleBody": "This comprehensive guide explains IP addresses - the unique identifiers that connect devices to the internet. Learn about IPv4 vs IPv6, how to find your IP, what information it reveals, and methods to protect your privacy including VPNs, proxies, and Tor.",
  "speakable": {
    "@type": "SpeakableSpecification",
    "xPath": [
      "/html/head/title",
      "/html/body/div[@class='container']/h1",
      "/html/body/div[@class='container']/p[1]"
    ]
  }
};

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What exactly is an IP address?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "An IP (Internet Protocol) address is a unique string of numbers assigned to every device connected to a network. It functions like a digital home address that identifies your device on the internet."
      }
    },
    {
      "@type": "Question",
      "name": "How can I find my IP address?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "You can find your public IP instantly by visiting TheIPChecker.com. Your IP and location details will be displayed automatically when the page loads."
      }
    },
    {
      "@type": "Question",
      "name": "Can someone track me through my IP address?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "While your IP doesn't reveal your exact physical address, it can show your approximate location (city/region) and Internet Service Provider. Websites and ISPs can log your activity associated with your IP."
      }
    },
    {
      "@type": "Question",
      "name": "What's the best way to hide my IP address?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "A VPN provides the best protection by masking your real IP with one from their server network. Other options include proxies (less secure) or Tor browser (slower but more anonymous)."
      }
    }
  ]
};

// Function to inject schemas into the page
function injectSchemas() {
  const scriptArticle = document.createElement('script');
  scriptArticle.type = 'application/ld+json';
  scriptArticle.text = JSON.stringify(ipArticleSchema);
  document.head.appendChild(scriptArticle);

  const scriptFAQ = document.createElement('script');
  scriptFAQ.type = 'application/ld+json';
  scriptFAQ.text = JSON.stringify(faqSchema);
  document.head.appendChild(scriptFAQ);
}

// Run on page load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectSchemas);
} else {
  injectSchemas();
}