// Load header and footer
fetch('header-main.html')
    .then(response => response.text())
    .then(html => {
        document.getElementById('header-placeholder').innerHTML = html;
        initializeMobileMenu();
    })
    .catch(error => console.error('Header load error:', error));

fetch('footer.html')
    .then(response => response.text())
    .then(html => {
        document.getElementById('footer-placeholder').innerHTML = html;
        document.getElementById('current-year').textContent = new Date().getFullYear();
    })
    .catch(error => console.error('Footer load error:', error));

// Mobile Menu Initialization
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mainNav = document.getElementById('main-nav');
    const dropdowns = document.querySelectorAll('.dropdown');
    
    if (mobileMenuBtn && mainNav) {
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            this.textContent = mainNav.classList.contains('active') ? '✕' : '☰';
        });
    }
    
    // Handle dropdowns on mobile
    dropdowns.forEach(dropdown => {
        const link = dropdown.querySelector('a');
        link.addEventListener('click', function(e) {
            if (window.innerWidth > 992) return;
            
            e.preventDefault();
            dropdown.classList.toggle('active');
        });
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Subnet Calculator Functionality
    const ipInput = document.getElementById('ip-address');
    const subnetMaskSelect = document.getElementById('subnet-mask');
    const customMaskRow = document.getElementById('custom-mask-row');
    const customMaskInput = document.getElementById('custom-mask');
    const calculateBtn = document.getElementById('calculate-btn');
    const errorMessage = document.getElementById('error-message');
    const resultSection = document.getElementById('result-section');
    
    // Result fields
    const resultIp = document.getElementById('result-ip');
    const networkAddress = document.getElementById('network-address');
    const hostRange = document.getElementById('host-range');
    const broadcastAddress = document.getElementById('broadcast-address');
    const subnetMaskResult = document.getElementById('result-subnet-mask');
    const wildcardMask = document.getElementById('wildcard-mask');
    const totalHosts = document.getElementById('total-hosts');
    const cidrNotation = document.getElementById('cidr-notation');
    const ipList = document.getElementById('ip-list');
    
    // Event listeners
    subnetMaskSelect.addEventListener('change', function() {
        customMaskRow.classList.toggle('show', this.value === '/custom');
    });
    
    calculateBtn.addEventListener('click', calculateSubnet);
    
    ipInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') calculateSubnet();
    });
    
    customMaskInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') calculateSubnet();
    });

    function calculateSubnet() {
        errorMessage.textContent = '';
        resultSection.classList.remove('show');
        
        const ipAddress = ipInput.value.trim();
        let subnetMask = subnetMaskSelect.value;
        
        if (subnetMask === '/custom') {
            subnetMask = customMaskInput.value.trim();
            if (!subnetMask) {
                errorMessage.textContent = 'Please enter a custom subnet mask';
                return;
            }
        } else {
            // Convert selected option to mask
            subnetMask = cidrToMask(parseInt(subnetMask.substring(1)));
        }
        
        if (!ipAddress) {
            errorMessage.textContent = 'Please enter an IP address';
            return;
        }
        
        try {
            const result = calculateSubnetInfo(ipAddress, subnetMask);
            displayResults(result);
        } catch (e) {
            errorMessage.textContent = e.message;
        }
    }
    
    function calculateSubnetInfo(ipAddress, subnetMask) {
        // Validate IP address
        if (!isValidIP(ipAddress)) {
            throw new Error('Invalid IP address format');
        }
        
        // Validate subnet mask
        if (!isValidSubnetMask(subnetMask)) {
            throw new Error('Invalid subnet mask');
        }
        
        const ipParts = ipAddress.split('.').map(Number);
        const maskParts = subnetMask.split('.').map(Number);
        
        // Calculate network address (IP AND Mask)
        const networkAddress = ipParts.map((part, i) => part & maskParts[i]);
        
        // Calculate wildcard mask (NOT Mask)
        const wildcardMask = maskParts.map(part => 255 - part);
        
        // Calculate broadcast address (Network OR Wildcard)
        const broadcastAddress = networkAddress.map((part, i) => part | wildcardMask[i]);
        
        // Calculate total hosts (2^hostBits)
        const hostBits = wildcardMask.reduce((acc, octet) => {
            return acc + octet.toString(2).split('1').length - 1;
        }, 0);
        
        const totalHosts = Math.pow(2, hostBits);
        const usableHosts = totalHosts > 2 ? totalHosts - 2 : totalHosts;
        
        // Calculate CIDR notation (count 1 bits in mask)
        const cidr = maskParts.reduce((acc, octet) => {
            return acc + octet.toString(2).split('1').length - 1;
        }, 0);
        
        // Generate IP range
        const ipRange = generateIPRange(networkAddress, broadcastAddress, cidr);
        
        return {
            ipAddress: ipAddress,
            subnetMask: subnetMask,
            networkAddress: networkAddress.join('.'),
            firstUsableHost: totalHosts > 1 ? incrementIP([...networkAddress]).join('.') : networkAddress.join('.'),
            lastUsableHost: totalHosts > 1 ? decrementIP([...broadcastAddress]).join('.') : broadcastAddress.join('.'),
            broadcastAddress: broadcastAddress.join('.'),
            wildcardMask: wildcardMask.join('.'),
            totalHosts: totalHosts,
            usableHosts: usableHosts,
            cidrNotation: `/${cidr}`,
            ipRange: ipRange
        };
    }
    
    function isValidIP(ip) {
        const ipRegex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        return ipRegex.test(ip);
    }
    
    function isValidSubnetMask(mask) {
        // Check if it's a valid IP first
        if (!isValidIP(mask)) return false;
        
        // Check if it's a valid subnet mask (continuous 1s followed by 0s)
        const binary = mask.split('.').map(octet => {
            return parseInt(octet).toString(2).padStart(8, '0');
        }).join('');
        
        return /^1+0*$/.test(binary);
    }
    
    function cidrToMask(cidr) {
        let mask = [];
        for (let i = 0; i < 4; i++) {
            const n = Math.min(cidr, 8);
            mask.push(256 - Math.pow(2, 8 - n));
            cidr -= n;
        }
        return mask.join('.');
    }
    
    function generateIPRange(start, end, cidr) {
        const ips = [];
        const current = [...start];
        const maxDisplay = 100; // Limit for display
        
        // For small ranges (<= maxDisplay), show all IPs
        if (Math.pow(2, 32 - cidr) <= maxDisplay) {
            while (compareIPs(current, end) <= 0) {
                ips.push(current.join('.'));
                incrementIP(current);
            }
            return ips.join('\n');
        }
        
        // For large ranges, show first and last 10 IPs
        let count = 0;
        while (count < 10 && compareIPs(current, end) <= 0) {
            ips.push(current.join('.'));
            incrementIP(current);
            count++;
        }
        
        ips.push('...');
        
        // Get last 10 IPs
        const lastIPs = [];
        const temp = [...end];
        count = 0;
        while (count < 10) {
            lastIPs.unshift(temp.join('.'));
            decrementIP(temp);
            count++;
        }
        
        return ips.concat(lastIPs).join('\n');
    }
    
    function incrementIP(ip) {
        for (let i = 3; i >= 0; i--) {
            if (ip[i] < 255) {
                ip[i]++;
                return ip;
            }
            ip[i] = 0;
        }
        return ip;
    }
    
    function decrementIP(ip) {
        for (let i = 3; i >= 0; i--) {
            if (ip[i] > 0) {
                ip[i]--;
                return ip;
            }
            ip[i] = 255;
        }
        return ip;
    }
    
    function compareIPs(ip1, ip2) {
        for (let i = 0; i < 4; i++) {
            if (ip1[i] < ip2[i]) return -1;
            if (ip1[i] > ip2[i]) return 1;
        }
        return 0;
    }
    
    function displayResults(result) {
        resultIp.textContent = result.ipAddress;
        networkAddress.textContent = result.networkAddress;
        hostRange.textContent = `${result.firstUsableHost} - ${result.lastUsableHost}`;
        broadcastAddress.textContent = result.broadcastAddress;
        subnetMaskResult.textContent = result.subnetMask;
        wildcardMask.textContent = result.wildcardMask;
        totalHosts.textContent = `${result.usableHosts} usable (${result.totalHosts} total)`;
        cidrNotation.textContent = result.cidrNotation;
        ipList.textContent = result.ipRange;
        
        if (result.totalHosts > 100) {
            ipList.innerHTML += '<div style="color: var(--dark-gray); margin-top: 10px;">Note: Displaying first and last 10 IPs only for large ranges.</div>';
        }
        
        resultSection.classList.add('show');
    }
});