// scripts/encryption-schema.js
document.addEventListener('DOMContentLoaded', function() {
    // Article Schema
    const articleSchema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "Encryption Explained: How It Protects Your Data Online",
        "description": "Complete guide to encryption technologies including HTTPS, SSL/TLS, and end-to-end encryption. Learn how encryption keeps your data secure online.",
        "author": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "url": "https://theipchecker.com"
        },
        "datePublished": "2025-07-20",
        "dateModified": "2025-07-20",
        "publisher": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "logo": {
                "@type": "ImageObject",
                "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.png",
                "width": 192,
                "height": 192
            }
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://theipchecker.com/encryption-guide"
        },
        "image": {
            "@type": "ImageObject",
            "url": "https://theipchecker.com/images/encryption.png",
            "width": 1200,
            "height": 630
        },
        "articleBody": "This comprehensive guide explains encryption - the process of encoding information to protect data online. Learn about symmetric and asymmetric encryption, common protocols like HTTPS/SSL/TLS, and how encryption safeguards your privacy. Discover how encryption algorithms work, their limitations, and why proper encryption is essential for secure online banking, communications, and transactions. Includes tools to test your connection security.",
        "keywords": [
            "encryption",
            "HTTPS",
            "SSL",
            "TLS",
            "data security",
            "end-to-end encryption",
            "cryptography",
            "AES",
            "RSA",
            "secure browsing"
        ],
        "speakable": {
            "@type": "SpeakableSpecification",
            "xPath": [
                "/html/head/title",
                "/html/body/main/h1",
                "/html/body/main/p[1]"
            ]
        }
    };

    // FAQ Schema
    const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "What is encryption and how does it work?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Encryption is the process of encoding information using complex algorithms to scramble readable data into unreadable ciphertext. It requires an encryption algorithm and a secret key to transform data securely."
                }
            },
            {
                "@type": "Question",
                "name": "What's the difference between symmetric and asymmetric encryption?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Symmetric encryption uses the same key for encryption and decryption (faster but requires secure key exchange), while asymmetric encryption uses a public/private key pair (solves key exchange but is slower)."
                }
            },
            {
                "@type": "Question",
                "name": "How can I tell if my connection is encrypted?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Look for HTTPS in your browser's address bar and the padlock icon. For comprehensive testing, use TheIPChecker.com's VPN and Encryption Test Tool to verify your connection security."
                }
            },
            {
                "@type": "Question",
                "name": "What are the most common encryption protocols?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Key protocols include HTTPS (SSL/TLS) for web traffic, PGP/GPG for emails, AES for file encryption, and RSA for secure data transmission."
                }
            }
        ]
    };

    // Create script tags and inject schemas
    function injectSchema(schema) {
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.text = JSON.stringify(schema);
        document.head.appendChild(script);
    }

    injectSchema(articleSchema);
    injectSchema(faqSchema);
});