// scripts/subnet-calculator-schemas.js
document.addEventListener('DOMContentLoaded', function() {
    // WebApplication Schema
    const webAppSchema = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "Subnet Calculator",
        "url": "https://theipchecker.com/subnet-calculator",
        "description": "Free online subnet calculator that calculates network addresses, subnet masks, IP ranges and other essential network information.",
        "applicationCategory": "NetworkUtility",
        "operatingSystem": "Any",
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
        },
        "creator": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "url": "https://theipchecker.com"
        },
        "datePublished": "2025-07-16",
        "dateModified": "2025-07-25",
        "screenshot": {
            "@type": "ImageObject",
            "url": "https://theipchecker.com/images/subnet-edu.png",
            "width": "1200",
            "height": "630"
        }
    };

    // FAQ Schema
    const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "What is a subnet calculator used for?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A subnet calculator helps network professionals determine all aspects of a subnet including network address, broadcast address, usable host range, subnet mask, and total number of hosts from an IP address and subnet mask."
                }
            },
            {
                "@type": "Question",
                "name": "How accurate is this subnet calculator?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Our subnet calculator provides 100% accurate results for all standard IPv4 subnet calculations, including CIDR notation and traditional subnet masks. It follows official networking standards and protocols."
                }
            },
            {
                "@type": "Question",
                "name": "Can this calculator handle CIDR notation?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, our subnet calculator fully supports CIDR notation (like /24, /16) and can convert between CIDR and traditional subnet mask formats (like 255.255.255.0)."
                }
            },
            {
                "@type": "Question",
                "name": "Does this tool support VLSM calculations?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes, our calculator supports Variable Length Subnet Masking (VLSM) through the custom subnet mask option, allowing you to input any valid subnet mask for precise network calculations."
                }
            }
        ]
    };

    // Breadcrumb Schema
    const breadcrumbSchema = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {
                "@type": "ListItem",
                "position": 1,
                "name": "Home",
                "item": "https://theipchecker.com"
            },
            {
                "@type": "ListItem",
                "position": 2,
                "name": "Tools",
                "item": "https://theipchecker.com/tools"
            },
            {
                "@type": "ListItem",
                "position": 3,
                "name": "Subnet Calculator",
                "item": "https://theipchecker.com/subnet-calculator"
            }
        ]
    };

    // Function to inject schema
    function injectSchema(schema) {
        try {
            const script = document.createElement('script');
            script.type = 'application/ld+json';
            script.text = JSON.stringify(schema, null, 2); // Pretty print JSON
            document.head.appendChild(script);
        } catch (e) {
            console.error('Error injecting schema:', e);
        }
    }

    // Inject all schemas
    injectSchema(webAppSchema);
    injectSchema(faqSchema);
    injectSchema(breadcrumbSchema);
});