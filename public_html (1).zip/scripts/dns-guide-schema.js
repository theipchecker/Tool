

// Article schema
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How DNS Works: The Internet's Phonebook Explained",
  "description": "Complete guide to the Domain Name System (DNS). Learn how DNS translates domain names to IP addresses and makes the internet work.",
  "author": {
    "@type": "Organization",
    "name": "TheIPChecker",
    "url": "https://theipchecker.com"
  },
  "datePublished": "2025-07-20",
  "dateModified": "2025-07-20",
  "publisher": {
    "@type": "Organization",
    "name": "TheIPChecker",
    "logo": {
      "@type": "ImageObject",
      "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.png",
      "width": 192,
      "height": 192
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://theipchecker.com/dns-guide"
  },
  "image": {
    "@type": "ImageObject",
    "url": "https://theipchecker.com/images/dns-edu.png",
    "width": 1200,
    "height": 630
  },
  "articleBody": "This comprehensive guide explains the Domain Name System (DNS) - the internet's phonebook that translates human-friendly domain names into machine-readable IP addresses. Learn about the DNS lookup process, different record types (A, AAAA, CNAME, MX), security vulnerabilities (spoofing, hijacking), and protection methods including DNSSEC and DNS over HTTPS. Discover why understanding DNS is crucial for troubleshooting, performance optimization, and online security.",
  "keywords": [
    "DNS",
    "Domain Name System",
    "how DNS works",
    "DNS lookup",
    "nameservers",
    "internet infrastructure",
    "DNS records",
    "DNSSEC",
    "DNS over HTTPS",
    "internet protocols"
  ],
  "speakable": {
    "@type": "SpeakableSpecification",
    "xPath": [
      "/html/head/title",
      "/html/body/main/h1",
      "/html/body/main/p[1]"
    ]
  }
};

// FAQ schema
const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is DNS and why is it important?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "DNS (Domain Name System) translates human-readable domain names (like theipchecker.com) into machine-readable IP addresses (like 192.0.2.1). It's essential because without DNS, we would need to remember numerical IP addresses for every website we visit."
      }
    },
    {
      "@type": "Question",
      "name": "How does a DNS lookup work?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "When you visit a website, your device first checks its local DNS cache. If not found, it queries recursive DNS servers, which then query root nameservers, TLD nameservers (.com, .org), and finally the domain's authoritative nameservers to get the IP address - all typically happening in milliseconds."
      }
    },
    {
      "@type": "Question",
      "name": "What are the main types of DNS records?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Key DNS record types include: A Records (IPv4 addresses), AAAA Records (IPv6 addresses), CNAME (domain aliases), MX (mail server records), and TXT (verification text records). Each serves a specific purpose in domain configuration."
      }
    },
    {
      "@type": "Question",
      "name": "How can I protect my DNS queries?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "For better DNS security: 1) Use DNSSEC to authenticate DNS responses, 2) Enable DNS over HTTPS (DoH) or DNS over TLS (DoT) to encrypt queries, 3) Use reputable DNS providers like Cloudflare or Google DNS, and 4) Regularly check for unauthorized DNS setting changes."
      }
    }
  ]
};

// Function to inject schemas into the page
function injectSchemas() {
  const scriptArticle = document.createElement('script');
  scriptArticle.type = 'application/ld+json';
  scriptArticle.textContent = JSON.stringify(articleSchema);
  document.head.appendChild(scriptArticle);

  const scriptFAQ = document.createElement('script');
  scriptFAQ.type = 'application/ld+json';
  scriptFAQ.textContent = JSON.stringify(faqSchema);
  document.head.appendChild(scriptFAQ);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectSchemas);
} else {
  injectSchemas();
}