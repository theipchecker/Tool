// Schema.org structured data
function injectSchemas() {
  // Main Tool Schema
  const toolSchema = {
    "@context": "https://schema.org",
    "@type": ["WebApplication", "Tool"],
    "name": "CIDR to IP Range Converter",
    "url": "https://theipchecker.com/cidr-to-ip-range-converter.html",
    "description": "Free online tool to convert CIDR notation (e.g., 192.168.0.0/24) to all IP addresses in that range. Perfect for network engineers and students.",
    "applicationCategory": "NetworkTool",
    "operatingSystem": "Any",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "creator": {
      "@type": "Organization",
      "name": "TheIPChecker",
      "url": "https://theipchecker.com"
    },
    "publisher": {
      "@type": "Organization",
      "name": "TheIPChecker",
      "logo": {
        "@type": "ImageObject",
        "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.png",
        "width": 192,
        "height": 192
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://theipchecker.com/cidr-to-ip-range-converter"
    },
    "image": {
      "@type": "ImageObject",
      "url": "https://theipchecker.com/images/cidr.jpg",
      "width": 1200,
      "height": 630
    },
    "interactionStatistic": {
      "@type": "InteractionCounter",
      "interactionType": "https://schema.org/UseAction",
      "userInteractionCount": 5000
    },
    "potentialAction": {
      "@type": "Action",
      "name": "Convert CIDR to IP Range",
      "description": "Enter CIDR notation to get IP address range",
      "target": {
        "@type": "EntryPoint",
        "urlTemplate": "https://theipchecker.com/cidr-to-ip-range-converter",
        "actionPlatform": [
          "http://schema.org/DesktopWebPlatform",
          "http://schema.org/MobileWebPlatform"
        ]
      }
    },
    "featureList": [
      "CIDR to IP range conversion",
      "Network address calculation",
      "Broadcast address detection",
      "Subnet mask display",
      "Wildcard mask calculation",
      "Total hosts calculation"
    ],
    "screenshot": {
      "@type": "ImageObject",
      "url": "https://theipchecker.com/images/cidr-screenshot.jpg",
      "width": 1280,
      "height": 720
    }
  };

  // FAQ Schema
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is CIDR notation?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "CIDR notation is a compact representation of an IP address and its associated routing prefix. It's written as the IP address followed by a slash (/) and the prefix length (number of leading 1 bits in the subnet mask). For example, 192.168.0.0/24 represents the IP addresses from 192.168.0.0 to 192.168.0.255."
        }
      },
      {
        "@type": "Question",
        "name": "Why would I need to convert CIDR to IP range?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Network administrators often need to know all the IP addresses in a particular subnet for configuration, security, or troubleshooting purposes. This tool provides that information instantly without manual calculations."
        }
      },
      {
        "@type": "Question",
        "name": "What's the maximum number of IPs this tool can display?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "For performance reasons, we limit the display to the first and last 10 IP addresses in ranges larger than 100 addresses. The complete count is always shown in the 'Total Hosts' field."
        }
      },
      {
        "@type": "Question",
        "name": "How accurate is this CIDR to IP range converter?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Our tool performs precise calculations following standard CIDR notation rules, providing accurate network addresses, broadcast addresses, and IP ranges for any valid CIDR input."
        }
      }
    ]
  };

  // Create script tags and inject into head
  const script1 = document.createElement('script');
  script1.type = 'application/ld+json';
  script1.text = JSON.stringify(toolSchema);
  document.head.appendChild(script1);

  const script2 = document.createElement('script');
  script2.type = 'application/ld+json';
  script2.text = JSON.stringify(faqSchema);
  document.head.appendChild(script2);
}

// Run when DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectSchemas);
} else {
  injectSchemas();
}