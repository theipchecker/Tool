document.addEventListener('DOMContentLoaded', function() {
    // Article Schema
    const articleSchema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "What is a VPN? Why It's Essential for Your Online Privacy",
        "description": "Learn how VPNs protect your privacy, hide your IP address, and secure your internet connection with this comprehensive guide.",
        "author": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "url": "https://theipchecker.com"
        },
        "datePublished": "2025-07-16",
        "dateModified": "2025-07-25",
        "publisher": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "logo": {
                "@type": "ImageObject",
                "url": "https://theipchecker.com/logo.png",
                "width": 300,
                "height": 60
            }
        },
        "image": {
            "@type": "ImageObject",
            "url": "https://theipchecker.com/images/vpn.png",
            "width": 1200,
            "height": 630
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://theipchecker.com/vpn-article"
        },
        "speakable": {
            "@type": "SpeakableSpecification",
            "xPath": [
                "/html/head/title",
                "/html/body/main/h1",
                "/html/body/main/p[1]"
            ]
        },
        "keywords": ["VPN", "Virtual Private Network", "online privacy", "IP masking", "internet security"],
        "articleBody": "A VPN creates a secure, encrypted tunnel between your device and the internet. It hides your real IP address and routes your traffic through a private server in another location. VPNs protect your privacy on public Wi-Fi, help bypass geo-restrictions, prevent ISP throttling, and stop tracking by advertisers."
    };

    // FAQ Schema
    const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "What is a VPN?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A VPN (Virtual Private Network) creates a secure, encrypted connection between your device and the internet, hiding your real IP address and location while protecting your data from surveillance."
                }
            },
            {
                "@type": "Question",
                "name": "Why should I use a VPN?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "You should use a VPN to protect your privacy on public Wi-Fi, hide your location from trackers, bypass geo-restrictions for streaming content, prevent ISP bandwidth throttling, and stop advertisers from tracking your online activity."
                }
            },
            {
                "@type": "Question",
                "name": "What's the difference between a VPN and proxy?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "While both hide your IP address, a VPN encrypts all your internet traffic at the system level, while proxies only work at the browser level without encryption, making them less secure."
                }
            }
        ]
    };

    // Function to inject schema
    function injectSchema(schema) {
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.text = JSON.stringify(schema);
        document.head.appendChild(script);
    }

    // Inject both schemas
    injectSchema(articleSchema);
    injectSchema(faqSchema);
});