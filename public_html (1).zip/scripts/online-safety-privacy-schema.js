// scripts/online-safety-schema.js
document.addEventListener('DOMContentLoaded', function() {
    const schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "Online Safety & Security: The Ultimate 2025 Protection Guide",
        "description": "Discover essential online safety tips to protect your privacy, data, and devices in 2025. Learn how to browse securely and avoid digital threats with our expert guide.",
        "author": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "url": "https://theipchecker.com"
        },
        "datePublished": "2025-07-20",
        "dateModified": "2025-07-20",
        "publisher": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "logo": {
                "@type": "ImageObject",
                "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.png",
                "width": "192",
                "height": "192"
            }
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://theipchecker.com/online-safety-privacy-article"
        },
        "image": {
            "@type": "ImageObject",
            "url": "https://theipchecker.com/images/education.png",
            "width": "1200",
            "height": "630"
        },
        "articleBody": "This 2025 protection guide covers critical cybersecurity threats including phishing scams, malware infections, public Wi-Fi vulnerabilities, data breaches, and identity theft. Learn essential security measures: using password managers, enabling 2FA, installing antivirus software, VPN usage on public networks, regular software updates, secure backup strategies, and scam recognition. The guide includes mobile security best practices, browser security enhancements, password management techniques, and recommended security tools. Test your current protection with our IP leak tests, VPN checks, and browser security assessments.",
        "keywords": [
            "online safety",
            "internet security",
            "privacy protection",
            "cybersecurity tips",
            "secure browsing",
            "digital protection",
            "2025 security guide",
            "VPN security",
            "password management",
            "malware protection"
        ],
        "speakable": {
            "@type": "SpeakableSpecification",
            "xPath": [
                "/html/head/title",
                "/html/body/div[@class='container']/h1",
                "/html/body/div[@class='container']/p[1]"
            ]
        }
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schema);
    document.head.appendChild(script);
});