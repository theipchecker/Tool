/**
 * Schema.org markup for Base64 Encoding Article
 * Includes Article and FAQPage structured data for TheIPChecker.com
 */

document.addEventListener('DOMContentLoaded', function() {
    // Article Schema for Base64 Encoding
    const articleSchema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "What Is Base64 Encoding? How it Works and Why It Matters",
        "description": "Learn what Base64 encoding is, why it's important, and how to use it securely. Try our free Base64 encoder/decoder tool at TheIPChecker.com.",
        "author": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "url": "https://theipchecker.com"
        },
        "datePublished": "2025-07-20",
        "dateModified": "2025-07-20",
        "publisher": {
            "@type": "Organization",
            "name": "TheIPChecker",
            "logo": {
                "@type": "ImageObject",
                "url": "https://theipchecker.com/favicon_io/android-chrome-192x192.png",
                "width": 192,
                "height": 192
            }
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://theipchecker.com/what-is-base64-encoding"
        },
        "image": {
            "@type": "ImageObject",
            "url": "https://theipchecker.com/images/base64-converter.png",
            "width": 1200,
            "height": 630
        },
        "articleBody": "This comprehensive guide explains Base64 encoding - a method for converting binary data into text format using 64 characters. Learn why Base64 is used for email attachments, data URIs, and API payloads, its security limitations, and how it impacts web performance. Discover real-world use cases including embedding images in HTML/CSS, sending binary files via APIs, and storing binary data in databases. Includes information about when to use Base64 versus traditional file hosting and how to use our free Base64 encoder/decoder tool.",
        "keywords": [
            "base64 encoder",
            "base64 decoder",
            "base64 converter",
            "online base64",
            "text to base64",
            "base64 to text",
            "data encoding",
            "binary to text",
            "web development",
            "data transmission"
        ],
        "speakable": {
            "@type": "SpeakableSpecification",
            "xPath": [
                "/html/head/title",
                "/html/body/div[@class='container']/h1",
                "/html/body/div[@class='container']/p[1]"
            ]
        }
    };

    // FAQ Schema for Base64 Encoding
    const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "What is Base64 encoding used for?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Base64 is used when binary data needs to be transported through media designed to handle text, such as emails (MIME), URLs, HTML/CSS files, JSON APIs, and data URIs in web development. Common use cases include embedding images in HTML/CSS, sending binary files via REST APIs, and storing binary data in databases as text."
                }
            },
            {
                "@type": "Question",
                "name": "Is Base64 encoding secure?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "No, Base64 is not a secure method of hiding or encrypting data. It's easily reversible. For sensitive information, use proper encryption techniques like AES, HTTPS/SSL for transport, or VPNs/private tunnels. Base64 should only be used for encoding, not for security purposes."
                }
            },
            {
                "@type": "Question",
                "name": "When should I use Base64 encoding for web assets?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Use Base64 for small images (under 5-10KB) when you want to reduce server requests and load assets inline. Avoid Base64 for larger files or when you need browser caching benefits. It's ideal for small icons, logos, or critical assets that need to load with the HTML."
                }
            },
            {
                "@type": "Question",
                "name": "What characters are used in Base64 encoding?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Base64 uses 64 characters: uppercase letters A-Z, lowercase letters a-z, numbers 0-9, plus the + and / symbols. The = character is used for padding at the end when needed to complete the encoding."
                }
            }
        ]
    };

    // Function to inject schema into document head
    function injectSchema(schema) {
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.text = JSON.stringify(schema);
        document.head.appendChild(script);
    }

    // Inject both schemas when DOM is loaded
    injectSchema(articleSchema);
    injectSchema(faqSchema);
});