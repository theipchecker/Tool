// gtm.js
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtg('js', new Date());
gtag('config', 'G-7TD9Q6CW6Y');
